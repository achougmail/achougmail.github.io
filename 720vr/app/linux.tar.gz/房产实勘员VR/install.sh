#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/share/icons"
mkdir -p "$HOME/.local/share/applications"
cp "$DIR/icon.png" "$HOME/.local/share/icons/房产实勘员VR.png" 2>/dev/null
cp "$DIR/房产实勘员VR.desktop" "$HOME/.local/share/applications/"
echo "✓ 房产实勘员VR 已安装到应用菜单"
